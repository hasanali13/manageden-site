// Opens a page someone has been to before from the phone itself, in a tenth of a second, instead
// of after a round trip to the server.
//
// WHY. Every file the pages use is already cached by the browser for a year (its name or ?v=
// changes when it does), but the page itself is "no-cache": each visit asked the server whether
// it had changed before anything could be drawn. From the Gulf that question costs a new
// connection and a round trip to Mumbai, 0.7 s or more, every time.
//
// WHAT.
// - A page (a navigation) is answered from the copy kept from the last visit, and the server is
//   asked for the current one at the same time; that copy is the one the next visit gets. A page
//   never seen before, or one asked for while the server is unreachable and nothing is kept,
//   goes to the network as usual.
// - Files whose name carries their content (main-*.js, chunk-*.js, styles-*.css, anything with a
//   ?v=) never change under that name, so they are answered from here once kept.
// - Everything else, the API above all, is left to the network: nothing private is kept here.
//
// A page kept from before a deploy may name the previous build's code. The console reloads itself
// once if such a file is gone (app.config.ts), by which time this has kept the new page.

const PAGES = 'pages-v1';
const FILES = 'files-v1';
const KEEP = [PAGES, FILES];
// How many versioned files to keep; older ones are dropped first.
const MAX_FILES = 400;

self.addEventListener('install', () => self.skipWaiting());

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const name of await caches.keys()) if (!KEEP.includes(name)) await caches.delete(name);
    await self.clients.claim();
  })());
});

const VERSIONED = /^\/(?:(?:main|chunk|polyfills|styles)-[\w-]+\.(?:js|css)$)/;

function keepable(response) {
  return response && response.ok && response.type === 'basic' && !response.redirected;
}

// A code or style file answered with a page is the server's fallback, not the file: never keep it.
function keepableFile(response) {
  return keepable(response) && !(response.headers.get('content-type') || '').includes('text/html');
}

async function trim() {
  const cache = await caches.open(FILES);
  const keys = await cache.keys();
  for (let i = 0; i < keys.length - MAX_FILES; i++) await cache.delete(keys[i]);
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname === '/health' || url.pathname === '/sw.js') return;

  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(PAGES);
      const kept = await cache.match(req, { ignoreSearch: false });
      const fresh = fetch(req).then((res) => {
        if (keepable(res)) cache.put(req, res.clone()).catch(() => {});
        return res;
      });
      if (kept) {
        event.waitUntil(fresh.catch(() => {}));
        return kept;
      }
      return fresh;
    })());
    return;
  }

  if (VERSIONED.test(url.pathname) || url.searchParams.has('v')) {
    event.respondWith((async () => {
      const cache = await caches.open(FILES);
      const kept = await cache.match(req);
      if (kept) return kept;
      const res = await fetch(req);
      if (keepableFile(res)) {
        event.waitUntil(cache.put(req, res.clone()).then(trim).catch(() => {}));
      }
      return res;
    })());
  }
});
