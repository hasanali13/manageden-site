# Landing page pictures

The photographs are from Unsplash and are free to use, including commercially, under the
[Unsplash License](https://unsplash.com/license). Credit is not required; it is kept here so
anyone can trace a picture back to its source.

| File | Photograph | By |
| --- | --- | --- |
| `band-fog-*` | [Skyscrapers emerge from thick fog in a city](https://unsplash.com/photos/skyscrapers-emerge-from-thick-fog-in-a-city-EFUAPmQUmgA) | Nick Hui |
| `hero-night-*` | [City skyline illuminated at night with a dark blue sky](https://unsplash.com/photos/city-skyline-illuminated-at-night-with-a-dark-blue-sky-1G7oszlOqcM) | CR (cr029) |
| `cta-lobby-*` | [Modern lobby with plush seating and decorative walls](https://unsplash.com/photos/modern-lobby-with-plush-seating-and-decorative-walls-aMFoc0cZENA) | Aalo Lens |
| `books-dusk-*` | [Curtain glass building during golden hour](https://unsplash.com/photos/curtain-glass-building-during-golden-hour-gOLWLtrQdzQ) (cropped to leave out the towers with company signs) | Ben Lodge |
| `amenity-pool-*` | [A luxurious rooftop swimming pool with city skyline views](https://unsplash.com/photos/a-luxurious-rooftop-swimming-pool-with-city-skyline-views-Tx0dfF6D41M) | Maverick Frame |
| `amenity-gym-*` | [Modern gym with treadmills and large windows](https://unsplash.com/photos/modern-gym-with-treadmills-and-large-windows-uYnHRrm63uo) | Aalo Lens |
| `amenity-lobby-*` | [Modern lobby with elevators and reception desk](https://unsplash.com/photos/modern-lobby-with-elevators-and-reception-desk-b08Pe9MV_eU) | Aalo Lens |
| `why-books-*` | [Modern glass skyscraper reflecting sunlight at sunset](https://unsplash.com/photos/modern-glass-skyscraper-reflecting-sunlight-at-sunset-oJuN4mzp_pk) | Douglas Schneiders |
| `why-tax-*` | [Modern glass skyscrapers against a clear blue sky](https://unsplash.com/photos/modern-glass-skyscrapers-against-a-clear-blue-sky-MXVVElrij7k) | Ronan Laker |
| `why-homes-*` | [Modern high-rise building with balconies and greenery](https://unsplash.com/photos/modern-high-rise-building-with-balconies-and-greenery-z72tjb_3tss) | Aalo Lens |
| `why-gate-*` | [A gated community entrance with a security booth](https://unsplash.com/photos/a-gated-community-entrance-with-a-security-booth-BtLoUZ6Ic7I) | Long Chung |
| `why-handover-*` | [A very tall building with a crane on top of it](https://unsplash.com/photos/a-very-tall-building-with-a-crane-on-top-of-it-n3ye52UITD0) | Andrea De Santis |

`console-*.webp`, `app-*.webp` and `role-*.webp` are recordings of ManageDen itself: the web
console (its sign-in, dashboard and list pages) and the mobile app as each role sees it.

# Sign-in footage (`public/login-film-*`)

`login-film-*.mp4` and `login-film-poster.webp` are one minute cut from three drone films on Wikimedia Commons,
each under [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/): trimmed, joined with
dissolves, colour-graded and re-encoded. They are credited on the site's credits page, `public/credits/index.html` (/credits/), linked from the privacy policy.

| Film | By |
| --- | --- |
| [Aerial views of Hells Kitchen and East Midtown Manhattan at night](https://commons.wikimedia.org/wiki/File:Aerial_views_of_Hells_Kitchen_and_East_Midtown_Manhattan_in_New_York_City,_USA_at_night.webm) | the Dronalist |
| [Charlotte By Night - 4K Drone Footage](https://commons.wikimedia.org/wiki/File:Charlotte_By_Night_-_4K_Drone_Footage.webm) | Hallum Creative |
| [Hong Kong Island Night Cityscape 2020](https://commons.wikimedia.org/wiki/File:Hong_Kong_Island_Night_Cityscape_2020.webm) | Bert Brothers |
