# City landmark pictures

Drop a file here to replace a city's drawn glyph in the "Cities we serve" row
with a real picture — a GIF, an APNG, a photo.

## Adding one

1. Put the file in this folder, e.g. `charminar.gif`.
2. Add `image` to that city in [`tools/seo/cities.mjs`](../../tools/seo/cities.mjs):

   ```js
   hyderabad: { label: 'Charminar', image: 'charminar.gif', path: '…' },
   ```

3. `npm run build:seo`

Keep the `path` — it stays as the fallback if the `image` line is ever removed.
Cities without an `image` keep their glyph, so this can be filled in one city at
a time rather than all twelve at once.

## Two things to get right

**Licensing.** Use only footage you own or that is licensed for commercial use.
These are marketing pages for a paid product, so a photograph pulled from a
search result is a real exposure, not a technicality. Wikimedia Commons is
usually the practical source — check each file's individual licence, since some
require attribution.

**Weight.** These pages exist to be found, and Google scores them partly on how
fast they load, so a row of twelve unoptimised GIFs is the kind of weight that
costs the ranking the pictures were added to win. Around **30 KB each** is a
safe ceiling at this size.

The chip renders the file at 15x15 CSS pixels, so export at 30x30 for a retina
screen — anything larger is bytes nobody sees. A short looping video or an APNG
will look better than a GIF at the same weight, because GIF is capped at 256
colours and dithers photographs badly.

Files are square-cropped (`object-fit: cover`) and slightly rounded, so a
non-square source is centre-cropped rather than squashed.

## Why the glyphs exist at all

The drawn SVG glyphs are the default because they carry no licence question,
cost roughly 300 bytes each, make no network request, and follow the light and
dark themes automatically via `currentColor`. A picture beats them on
recognition and loses on all four of those, which is the trade being made here.
